"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface User {
  id: string
  email: string
  name: string
  role: "admin" | "client"
  status: "pending" | "approved" | "rejected"
  createdAt: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (email: string, password: string, name: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
  getAllUsers: () => User[]
  approveUser: (userId: string) => void
  rejectUser: (userId: string) => void
  deleteUser: (userId: string) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem("khitab_user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }

    const users = JSON.parse(localStorage.getItem("khitab_users") || "[]")
    if (users.length === 0) {
      const defaultAdmin: User = {
        id: "admin-1",
        email: "admin@khitab.com",
        name: "مدير النظام",
        role: "admin",
        status: "approved",
        createdAt: new Date().toISOString(),
      }
      localStorage.setItem("khitab_users", JSON.stringify([defaultAdmin]))
    }

    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call - replace with actual authentication
    const users = JSON.parse(localStorage.getItem("khitab_users") || "[]")
    const foundUser = users.find((u: User) => u.email === email)

    if (foundUser && foundUser.status === "approved") {
      setUser(foundUser)
      localStorage.setItem("khitab_user", JSON.stringify(foundUser))
      setIsLoading(false)
      return true
    }

    setIsLoading(false)
    return false
  }

  const register = async (email: string, password: string, name: string): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call - replace with actual registration
    const users = JSON.parse(localStorage.getItem("khitab_users") || "[]")
    const existingUser = users.find((u: User) => u.email === email)

    if (existingUser) {
      setIsLoading(false)
      return false
    }

    const newUser: User = {
      id: Date.now().toString(),
      email,
      name,
      role: "client",
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    localStorage.setItem("khitab_users", JSON.stringify(users))

    setIsLoading(false)
    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("khitab_user")
  }

  const getAllUsers = (): User[] => {
    return JSON.parse(localStorage.getItem("khitab_users") || "[]")
  }

  const approveUser = (userId: string) => {
    const users = getAllUsers()
    const updatedUsers = users.map((u) => (u.id === userId ? { ...u, status: "approved" as const } : u))
    localStorage.setItem("khitab_users", JSON.stringify(updatedUsers))
  }

  const rejectUser = (userId: string) => {
    const users = getAllUsers()
    const updatedUsers = users.map((u) => (u.id === userId ? { ...u, status: "rejected" as const } : u))
    localStorage.setItem("khitab_users", JSON.stringify(updatedUsers))
  }

  const deleteUser = (userId: string) => {
    const users = getAllUsers()
    const updatedUsers = users.filter((u) => u.id !== userId)
    localStorage.setItem("khitab_users", JSON.stringify(updatedUsers))
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        isLoading,
        getAllUsers,
        approveUser,
        rejectUser,
        deleteUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
