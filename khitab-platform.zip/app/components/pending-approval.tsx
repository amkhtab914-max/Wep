"use client"

import { useAuth } from "../contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export function PendingApproval() {
  const { logout, user } = useAuth()

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-100 flex items-center justify-center">
      <div className="container mx-auto px-4">
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-2">في انتظار الموافقة</h2>

              <p className="text-gray-600 mb-2">مرحباً {user?.name}</p>

              <p className="text-gray-600 mb-6">
                تم إنشاء حسابك بنجاح وهو الآن قيد المراجعة من قبل الإدارة. ستتمكن من الوصول إلى المنصة بمجرد الموافقة
                على حسابك.
              </p>

              <div className="space-y-3">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>البريد الإلكتروني:</strong> {user?.email}
                  </p>
                  <p className="text-sm text-blue-800">
                    <strong>تاريخ التسجيل:</strong>{" "}
                    {user?.createdAt ? new Date(user.createdAt).toLocaleDateString("ar-SA") : ""}
                  </p>
                </div>

                <Button onClick={logout} variant="outline" className="w-full bg-transparent">
                  تسجيل الخروج
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
