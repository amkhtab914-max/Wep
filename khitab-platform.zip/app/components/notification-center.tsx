"use client"

import { useState } from "react"
import { Bell, X, CheckCircle, AlertTriangle, Info, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Notification {
  id: string
  type: "signal" | "news" | "alert" | "system"
  title: string
  message: string
  time: string
  read: boolean
  priority: "high" | "medium" | "low"
}

const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "signal",
    title: "إشارة جديدة - EUR/USD",
    message: "إشارة شراء قوية على EUR/USD مع مستوى ثقة 92%",
    time: "منذ دقيقتين",
    read: false,
    priority: "high",
  },
  {
    id: "2",
    type: "news",
    title: "أخبار اقتصادية مهمة",
    message: "البنك المركزي الأمريكي يعلن عن قرار أسعار الفائدة",
    time: "منذ 15 دقيقة",
    read: false,
    priority: "high",
  },
  {
    id: "3",
    type: "alert",
    title: "تنبيه سعر",
    message: "وصل EUR/USD إلى مستوى المقاومة 1.0900",
    time: "منذ 30 دقيقة",
    read: true,
    priority: "medium",
  },
  {
    id: "4",
    type: "system",
    title: "تحديث النظام",
    message: "تم تحديث منصة التداول بميزات جديدة",
    time: "منذ ساعة",
    read: true,
    priority: "low",
  },
]

export function NotificationCenter() {
  const [notifications, setNotifications] = useState(mockNotifications)
  const [isOpen, setIsOpen] = useState(false)

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "signal":
        return <TrendingUp className="w-4 h-4 text-green-400" />
      case "news":
        return <Info className="w-4 h-4 text-blue-400" />
      case "alert":
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />
      case "system":
        return <CheckCircle className="w-4 h-4 text-gray-400" />
      default:
        return <Bell className="w-4 h-4" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "border-r-red-500"
      case "medium":
        return "border-r-yellow-500"
      case "low":
        return "border-r-gray-500"
      default:
        return "border-r-gray-500"
    }
  }

  return (
    <div className="relative">
      <Button
        variant="outline"
        size="sm"
        className="text-white border-gray-600 bg-transparent hover:bg-gray-700 relative"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Bell className="w-4 h-4 ml-2" />
        التنبيهات
        {unreadCount > 0 && (
          <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs min-w-[20px] h-5 flex items-center justify-center rounded-full">
            {unreadCount}
          </Badge>
        )}
      </Button>

      {isOpen && (
        <div className="absolute left-0 top-full mt-2 w-96 bg-gray-800 border border-gray-700 rounded-lg shadow-xl z-50">
          <div className="p-4 border-b border-gray-700">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">التنبيهات</h3>
              <div className="flex items-center space-x-2 space-x-reverse">
                {unreadCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                    قراءة الكل
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-4 text-center text-gray-400">لا توجد تنبيهات جديدة</div>
            ) : (
              notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 border-b border-gray-700 hover:bg-gray-700 cursor-pointer border-r-4 ${getPriorityColor(notification.priority)} ${
                    !notification.read ? "bg-gray-750" : ""
                  }`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className="flex items-start space-x-3 space-x-reverse">
                    <div className="flex-shrink-0 mt-1">{getNotificationIcon(notification.type)}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className={`text-sm font-medium ${!notification.read ? "text-white" : "text-gray-300"}`}>
                          {notification.title}
                        </h4>
                        {!notification.read && <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0"></div>}
                      </div>
                      <p className="text-sm text-gray-400 mt-1">{notification.message}</p>
                      <p className="text-xs text-gray-500 mt-2">{notification.time}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-4 border-t border-gray-700">
            <Button variant="outline" size="sm" className="w-full bg-transparent">
              عرض جميع التنبيهات
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
