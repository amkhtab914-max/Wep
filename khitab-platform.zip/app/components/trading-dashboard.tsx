"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  BarChart3,
  Bell,
  Globe,
  Activity,
  Zap,
  BookOpen,
  Calculator,
  Users,
  Home,
  PieChart,
  Calendar,
  MessageSquare,
  Award,
  TrendingUpIcon,
  Maximize2,
  Settings,
  RefreshCw,
  Clock,
  CheckCircle,
  XCircle,
  Star,
  Filter,
  Download,
  Share2,
  Play,
  FileText,
  Video,
  Search,
  ChevronRight,
  User,
  Clock3,
  Eye,
  Target,
  AlertTriangle,
} from "lucide-react"

import { NotificationCenter } from "./notification-center"

const mockSignals = [
  {
    id: 1,
    pair: "EUR/USD",
    type: "BUY",
    entry: 1.085,
    tp: [1.092, 1.095, 1.098],
    sl: 1.08,
    strategy: "استراتيجية الاختراق",
    market: "forex",
    time: "منذ 5 دقائق",
    status: "active",
    confidence: 85,
    riskReward: "1:3",
    analyst: "أحمد محمد",
    description: "اختراق مستوى المقاومة 1.0845 مع حجم تداول عالي",
    currentPrice: 1.0847,
    pips: "+2",
    profit: "+$45",
    tags: ["اختراق", "حجم عالي", "ترند صاعد"],
  },
  {
    id: 2,
    pair: "BTC/USDT",
    type: "SELL",
    entry: 43500,
    tp: [42800, 42500, 42200],
    sl: 44200,
    strategy: "استراتيجية RSI",
    market: "crypto",
    time: "منذ 12 دقيقة",
    status: "active",
    confidence: 78,
    riskReward: "1:2.5",
    analyst: "سارة أحمد",
    description: "RSI في منطقة التشبع الشرائي مع تباعد سلبي",
    currentPrice: 43420,
    pips: "-80",
    profit: "+$120",
    tags: ["RSI", "تباعد سلبي", "تشبع شرائي"],
  },
  {
    id: 3,
    pair: "GBP/JPY",
    type: "BUY",
    entry: 185.2,
    tp: [186.5, 187.0, 187.5],
    sl: 184.0,
    strategy: "استراتيجية MACD",
    market: "forex",
    time: "منذ 25 دقيقة",
    status: "closed",
    confidence: 92,
    riskReward: "1:2.8",
    analyst: "محمد علي",
    description: "إشارة شراء قوية من MACD مع كسر خط الإشارة",
    currentPrice: 186.8,
    pips: "+160",
    profit: "+$280",
    tags: ["MACD", "إشارة قوية", "ربح محقق"],
  },
  {
    id: 4,
    pair: "XAU/USD",
    type: "BUY",
    entry: 2045.5,
    tp: [2055.0, 2065.0, 2075.0],
    sl: 2038.0,
    strategy: "استراتيجية الدعم والمقاومة",
    market: "commodities",
    time: "منذ 8 دقائق",
    status: "active",
    confidence: 88,
    riskReward: "1:4",
    analyst: "فاطمة حسن",
    description: "ارتداد من مستوى الدعم القوي مع تأكيد من حجم التداول",
    currentPrice: 2048.2,
    pips: "+27",
    profit: "+$67",
    tags: ["ذهب", "دعم قوي", "ارتداد"],
  },
  {
    id: 5,
    pair: "USD/CAD",
    type: "SELL",
    entry: 1.358,
    tp: [1.352, 1.348, 1.344],
    sl: 1.362,
    strategy: "استراتيجية الأخبار الاقتصادية",
    market: "forex",
    time: "منذ 3 دقائق",
    status: "pending",
    confidence: 75,
    riskReward: "1:3.5",
    analyst: "عمر خالد",
    description: "توقع انخفاض الدولار الكندي بعد بيانات التضخم الضعيفة",
    currentPrice: 1.3575,
    pips: "0",
    profit: "$0",
    tags: ["أخبار اقتصادية", "تضخم", "انتظار"],
  },
]

const mockPrices = [
  { pair: "EUR/USD", price: 1.0852, change: 0.0012, changePercent: 0.11 },
  { pair: "GBP/USD", price: 1.2634, change: -0.0023, changePercent: -0.18 },
  { pair: "USD/JPY", price: 149.85, change: 0.45, changePercent: 0.3 },
  { pair: "BTC/USDT", price: 43520, change: -280, changePercent: -0.64 },
  { pair: "ETH/USDT", price: 2650, change: 45, changePercent: 1.73 },
  { pair: "XRP/USDT", price: 0.6234, change: 0.0156, changePercent: 2.57 },
]

const mockNews = [
  "البنك المركزي الأوروبي يرفع أسعار الفائدة بـ 0.25%",
  "بيتكوين تتجاوز مستوى 44,000 دولار وسط تفاؤل المستثمرين",
  "الدولار الأمريكي يسجل أعلى مستوياته مقابل الين الياباني",
  "أسعار النفط ترتفع 2% بعد قرارات أوبك الجديدة",
]

const strategies = [
  "جميع الاستراتيجيات",
  "استراتيجية الاختراق",
  "استراتيجية RSI",
  "استراتيجية MACD",
  "استراتيجية الدعم والمقاومة",
  "استراتيجية الأخبار الاقتصادية",
  "استراتيجية فيبوناتشي",
  "استراتيجية المتوسطات المتحركة",
  "استراتيجية البولينجر باند",
  "استراتيجية الستوكاستيك",
]

const educationalContent = {
  strategies: [
    {
      id: 1,
      title: "استراتيجية الاختراق",
      description: "تعلم كيفية تحديد نقاط الاختراق القوية والدخول في الصفقات المربحة",
      level: "متوسط",
      duration: "45 دقيقة",
      views: 2847,
      rating: 4.8,
      instructor: "أحمد محمد",
      type: "video",
      thumbnail: "/trading-breakout-strategy-chart.png",
    },
    {
      id: 2,
      title: "استراتيجية RSI المتقدمة",
      description: "استخدام مؤشر القوة النسبية في تحديد نقاط الدخول والخروج المثلى",
      level: "متقدم",
      duration: "60 دقيقة",
      views: 1923,
      rating: 4.9,
      instructor: "سارة أحمد",
      type: "video",
      thumbnail: "/rsi-indicator-trading-strategy.png",
    },
    {
      id: 3,
      title: "إدارة المخاطر في التداول",
      description: "الأسس الصحيحة لإدارة رأس المال وتقليل المخاطر",
      level: "مبتدئ",
      duration: "30 دقيقة",
      views: 4521,
      rating: 4.7,
      instructor: "محمد علي",
      type: "article",
      thumbnail: "/risk-management-trading-chart.png",
    },
  ],
  courses: [
    {
      id: 1,
      title: "دورة التداول الشاملة للمبتدئين",
      description: "دورة كاملة تغطي جميع أساسيات التداول من الصفر حتى الاحتراف",
      level: "مبتدئ",
      duration: "12 ساعة",
      lessons: 24,
      students: 1847,
      rating: 4.9,
      instructor: "فريق خطاب التعليمي",
      price: "مجاني",
      progress: 0,
      thumbnail: "/trading-course-beginner-education.png",
    },
    {
      id: 2,
      title: "التحليل الفني المتقدم",
      description: "تعلم أدوات التحليل الفني المتقدمة والمؤشرات الاحترافية",
      level: "متقدم",
      duration: "8 ساعات",
      lessons: 16,
      students: 923,
      rating: 4.8,
      instructor: "خالد حسن",
      price: "$99",
      progress: 0,
      thumbnail: "/technical-analysis-advanced-charts.png",
    },
    {
      id: 3,
      title: "استراتيجيات التداول اليومي",
      description: "استراتيجيات مجربة للتداول اليومي وتحقيق أرباح ثابتة",
      level: "متوسط",
      duration: "6 ساعات",
      lessons: 12,
      students: 1234,
      rating: 4.6,
      instructor: "عمر خالد",
      price: "$79",
      progress: 25,
      thumbnail: "/day-trading-strategies-charts.png",
    },
  ],
  webinars: [
    {
      id: 1,
      title: "تحليل الأسواق الأسبوعي",
      description: "جلسة تحليل مباشرة لأهم الأزواج والفرص المتاحة",
      date: "2024-01-15",
      time: "20:00",
      duration: "90 دقيقة",
      instructor: "أحمد محمد",
      attendees: 234,
      status: "upcoming",
      thumbnail: "/market-analysis-webinar-live.png",
    },
    {
      id: 2,
      title: "استراتيجيات التداول في الأسواق المتقلبة",
      description: "كيفية التعامل مع التقلبات العالية وتحقيق الأرباح",
      date: "2024-01-08",
      time: "19:00",
      duration: "60 دقيقة",
      instructor: "سارة أحمد",
      attendees: 189,
      status: "completed",
      thumbnail: "/volatile-markets-trading-strategies.png",
    },
  ],
  articles: [
    {
      id: 1,
      title: "أساسيات التحليل الأساسي",
      description: "دليل شامل لفهم التحليل الأساسي وتأثيره على الأسواق",
      author: "محمد علي",
      date: "2024-01-10",
      readTime: "8 دقائق",
      views: 1523,
      category: "تحليل أساسي",
      thumbnail: "/fundamental-analysis-economic-data.png",
    },
    {
      id: 2,
      title: "نفسية التداول وإدارة العواطف",
      description: "كيفية التحكم في العواطف والحفاظ على الانضباط في التداول",
      author: "فاطمة حسن",
      date: "2024-01-08",
      readTime: "12 دقيقة",
      views: 2341,
      category: "علم النفس",
      thumbnail: "/trading-psychology-emotions-control.png",
    },
    {
      id: 3,
      title: "أفضل أوقات التداول في الأسواق العالمية",
      description: "دليل مفصل لأوقات التداول المثلى لكل سوق",
      author: "عمر خالد",
      date: "2024-01-05",
      readTime: "6 دقائق",
      views: 1876,
      category: "أساسيات",
      thumbnail: "/trading-sessions-global-markets-time.png",
    },
  ],
}

export function TradingDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [selectedMarket, setSelectedMarket] = useState("all")
  const [newsIndex, setNewsIndex] = useState(0)
  const [selectedSymbol, setSelectedSymbol] = useState("EURUSD")
  const [selectedTimeframe, setSelectedTimeframe] = useState("1h")
  const [chartType, setChartType] = useState("forex")
  const [selectedStrategy, setSelectedStrategy] = useState("جميع الاستراتيجيات")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [sortBy, setSortBy] = useState("time")
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setNewsIndex((prev) => (prev + 1) % mockNews.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  const filteredSignals = mockSignals
    .filter((signal) => {
      const marketMatch = selectedMarket === "all" || signal.market === selectedMarket
      const strategyMatch = selectedStrategy === "جميع الاستراتيجيات" || signal.strategy === selectedStrategy
      const statusMatch = selectedStatus === "all" || signal.status === selectedStatus
      return marketMatch && strategyMatch && statusMatch
    })
    .sort((a, b) => {
      if (sortBy === "time") return new Date(b.time) - new Date(a.time)
      if (sortBy === "confidence") return b.confidence - a.confidence
      if (sortBy === "profit")
        return Number.parseFloat(b.profit.replace(/[^-\d.]/g, "")) - Number.parseFloat(a.profit.replace(/[^-\d.]/g, ""))
      return 0
    })

  const getStatusInfo = (status) => {
    switch (status) {
      case "active":
        return { icon: Activity, color: "text-green-400", bg: "bg-green-400/10", text: "نشط" }
      case "closed":
        return { icon: CheckCircle, color: "text-blue-400", bg: "bg-blue-400/10", text: "مغلق" }
      case "pending":
        return { icon: Clock, color: "text-yellow-400", bg: "bg-yellow-400/10", text: "انتظار" }
      case "cancelled":
        return { icon: XCircle, color: "text-red-400", bg: "bg-red-400/10", text: "ملغي" }
      default:
        return { icon: Activity, color: "text-gray-400", bg: "bg-gray-400/10", text: "غير محدد" }
    }
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white" dir="rtl">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 py-2 overflow-hidden shadow-lg">
        \
        <div className="flex items-center">
          <div className="flex items-center px-6 bg-blue-800 text-sm font-medium rounded-l-lg">
            <Globe className="w-4 h-4 ml-2" />\ الأخبار المالية العاجلة
          </div>
          <div className="flex-1 px-4">
            <div className="animate-pulse text-sm font-medium">{mockNews[newsIndex]}</div>
          </div>
        </div>
      </div>

      <header className="bg-gray-800 border-b border-gray-700 px-6 py-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6 space-x-reverse">
            <div className="flex items-center">
              <BarChart3 className="w-8 h-8 text-blue-400 ml-3" />
              <div>
                <h1 className="text-2xl font-bold">منصة خطاب للتداول</h1>
                <p className="text-sm text-gray-400">المنصة الشاملة للتوصيات والتحليل</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4 space-x-reverse">
            <NotificationCenter />
            <div className="flex items-center text-sm text-gray-300 bg-gray-700 px-3 py-2 rounded-lg">
              <Activity className="w-4 h-4 ml-2 text-green-400" />
              متصل - آخر تحديث: الآن
            </div>
            <div className="flex items-center space-x-2 space-x-reverse bg-gray-700 px-3 py-2 rounded-lg">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-sm font-bold">
                م
              </div>
              <div className="text-sm">
                <div className="font-medium">محمد أحمد</div>
                <div className="text-gray-400">عضو مميز</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        <aside className="w-80 bg-gray-800 border-l border-gray-700 p-4 min-h-screen">
          {/* Navigation Menu */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wide">القائمة الرئيسية</h3>
            <nav className="space-y-2">
              <Button
                variant={activeTab === "dashboard" ? "default" : "ghost"}
                className="w-full justify-start text-right"
                onClick={() => setActiveTab("dashboard")}
              >
                <Home className="w-4 h-4 ml-2" />
                لوحة التحكم
              </Button>
              <Button
                variant={activeTab === "signals" ? "default" : "ghost"}
                className="w-full justify-start text-right"
                onClick={() => setActiveTab("signals")}
              >
                <Zap className="w-4 h-4 ml-2" />
                التوصيات المباشرة
              </Button>
              <Button
                variant={activeTab === "charts" ? "default" : "ghost"}
                className="w-full justify-start text-right"
                onClick={() => setActiveTab("charts")}
              >
                <BarChart3 className="w-4 h-4 ml-2" />
                الرسوم البيانية
              </Button>
              <Button
                variant={activeTab === "education" ? "default" : "ghost"}
                className="w-full justify-start text-right"
                onClick={() => setActiveTab("education")}
              >
                <BookOpen className="w-4 h-4 ml-2" />
                المكتبة التعليمية
              </Button>
              <Button
                variant={activeTab === "tools" ? "default" : "ghost"}
                className="w-full justify-start text-right"
                onClick={() => setActiveTab("tools")}
              >
                <Calculator className="w-4 h-4 ml-2" />
                أدوات التداول
              </Button>
              <Button
                variant={activeTab === "community" ? "default" : "ghost"}
                className="w-full justify-start text-right"
                onClick={() => setActiveTab("community")}
              >
                <Users className="w-4 h-4 ml-2" />
                المجتمع
              </Button>
              <Button
                variant={activeTab === "news" ? "default" : "ghost"}
                className="w-full justify-start text-right"
                onClick={() => setActiveTab("news")}
              >
                <Globe className="w-4 h-4 ml-2" />
                الأخبار الاقتصادية
              </Button>
            </nav>
          </div>

          {/* Live Prices Section */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <DollarSign className="w-5 h-5 ml-2 text-green-400" />
              الأسعار المباشرة
            </h3>
            <div className="space-y-3">
              {mockPrices.map((item, index) => (
                <div
                  key={index}
                  className="bg-gray-700 rounded-lg p-3 hover:bg-gray-600 transition-colors cursor-pointer"
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-medium">{item.pair}</span>
                    <span className="text-lg font-bold">{item.price.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className={`flex items-center ${item.change >= 0 ? "text-green-400" : "text-red-400"}`}>
                      {item.change >= 0 ? (
                        <TrendingUp className="w-3 h-3 ml-1" />
                      ) : (
                        <TrendingDown className="w-3 h-3 ml-1" />
                      )}
                      {item.change >= 0 ? "+" : ""}
                      {item.change}
                    </span>
                    <span className={item.changePercent >= 0 ? "text-green-400" : "text-red-400"}>
                      {item.changePercent >= 0 ? "+" : ""}
                      {item.changePercent}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-gray-700 rounded-lg p-4">
            <h4 className="font-semibold mb-3">إحصائيات سريعة</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">التوصيات النشطة:</span>
                <span className="text-green-400 font-bold">12</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">نسبة النجاح:</span>
                <span className="text-blue-400 font-bold">87%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">الربح الشهري:</span>
                <span className="text-green-400 font-bold">+15.3%</span>
              </div>
            </div>
          </div>
        </aside>

        <main className="flex-1 p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsContent value="dashboard" className="space-y-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">لوحة التحكم الرئيسية</h2>
                <div className="text-sm text-gray-400">آخر تحديث: {new Date().toLocaleString("ar-SA")}</div>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card className="bg-gradient-to-br from-blue-600 to-blue-700 border-blue-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-100 text-sm">التوصيات النشطة</p>
                        <p className="text-3xl font-bold text-white">12</p>
                      </div>
                      <Zap className="w-8 h-8 text-blue-200" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-green-600 to-green-700 border-green-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-green-100 text-sm">نسبة النجاح</p>
                        <p className="text-3xl font-bold text-white">87%</p>
                      </div>
                      <TrendingUpIcon className="w-8 h-8 text-green-200" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-600 to-purple-700 border-purple-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-purple-100 text-sm">الربح الشهري</p>
                        <p className="text-3xl font-bold text-white">+15.3%</p>
                      </div>
                      <PieChart className="w-8 h-8 text-purple-200" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-orange-600 to-orange-700 border-orange-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-orange-100 text-sm">المتابعون</p>
                        <p className="text-3xl font-bold text-white">2,847</p>
                      </div>
                      <Users className="w-8 h-8 text-orange-200" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <h3 className="text-lg font-semibold">آخر التوصيات</h3>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockSignals.slice(0, 3).map((signal) => (
                        <div key={signal.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                          <div className="flex items-center space-x-3 space-x-reverse">
                            <Badge variant={signal.type === "BUY" ? "default" : "destructive"} className="text-xs">
                              {signal.type}
                            </Badge>
                            <span className="font-medium">{signal.pair}</span>
                          </div>
                          <div className="text-sm text-gray-400">{signal.time}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <h3 className="text-lg font-semibold">الأداء الأسبوعي</h3>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">الأحد</span>
                        <span className="text-green-400 font-bold">+2.1%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">الاثنين</span>
                        <span className="text-green-400 font-bold">+1.8%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">الثلاثاء</span>
                        <span className="text-red-400 font-bold">-0.5%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">الأربعاء</span>
                        <span className="text-green-400 font-bold">+3.2%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">الخميس</span>
                        <span className="text-green-400 font-bold">+1.9%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="signals" className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <h2 className="text-xl font-semibold">التوصيات المباشرة</h2>
                  <Badge variant="outline" className="bg-green-400/10 text-green-400 border-green-400/20">
                    <Activity className="w-3 h-3 ml-1" />
                    مباشر
                  </Badge>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)}>
                    <Filter className="w-4 h-4 ml-2" />
                    فلترة
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 ml-2" />
                    تصدير
                  </Button>
                  <Button variant="outline" size="sm">
                    <RefreshCw className="w-4 h-4 ml-2" />
                    تحديث
                  </Button>
                </div>
              </div>

              {showFilters && (
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-400 mb-2 block">السوق</label>
                        <select
                          value={selectedMarket}
                          onChange={(e) => setSelectedMarket(e.target.value)}
                          className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                        >
                          <option value="all">جميع الأسواق</option>
                          <option value="forex">فوركس</option>
                          <option value="crypto">كريبتو</option>
                          <option value="commodities">السلع</option>
                          <option value="indices">المؤشرات</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-400 mb-2 block">الاستراتيجية</label>
                        <select
                          value={selectedStrategy}
                          onChange={(e) => setSelectedStrategy(e.target.value)}
                          className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                        >
                          {strategies.map((strategy) => (
                            <option key={strategy} value={strategy}>
                              {strategy}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-400 mb-2 block">الحالة</label>
                        <select
                          value={selectedStatus}
                          onChange={(e) => setSelectedStatus(e.target.value)}
                          className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                        >
                          <option value="all">جميع الحالات</option>
                          <option value="active">نشط</option>
                          <option value="closed">مغلق</option>
                          <option value="pending">انتظار</option>
                          <option value="cancelled">ملغي</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-400 mb-2 block">ترتيب حسب</label>
                        <select
                          value={sortBy}
                          onChange={(e) => setSortBy(e.target.value)}
                          className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                        >
                          <option value="time">الوقت</option>
                          <option value="confidence">مستوى الثقة</option>
                          <option value="profit">الربح/الخسارة</option>
                        </select>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant={selectedMarket === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedMarket("all")}
                >
                  الكل ({mockSignals.length})
                </Button>
                <Button
                  variant={selectedMarket === "forex" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedMarket("forex")}
                >
                  فوركس ({mockSignals.filter((s) => s.market === "forex").length})
                </Button>
                <Button
                  variant={selectedMarket === "crypto" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedMarket("crypto")}
                >
                  كريبتو ({mockSignals.filter((s) => s.market === "crypto").length})
                </Button>
                <Button
                  variant={selectedMarket === "commodities" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedMarket("commodities")}
                >
                  السلع ({mockSignals.filter((s) => s.market === "commodities").length})
                </Button>
              </div>

              <div className="grid gap-4">
                {filteredSignals.map((signal) => {
                  const statusInfo = getStatusInfo(signal.status)
                  const StatusIcon = statusInfo.icon

                  return (
                    <Card
                      key={signal.id}
                      className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg"
                    >
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3 space-x-reverse">
                            <Badge
                              variant={signal.type === "BUY" ? "default" : "destructive"}
                              className="text-sm font-bold"
                            >
                              {signal.type}
                            </Badge>
                            <span className="text-xl font-bold">{signal.pair}</span>
                            <Badge variant="outline" className="text-xs">
                              {signal.market === "forex" ? "فوركس" : signal.market === "crypto" ? "كريبتو" : "سلع"}
                            </Badge>
                            <div className="flex items-center space-x-1 space-x-reverse">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-3 h-3 ${
                                    i < Math.floor(signal.confidence / 20)
                                      ? "text-yellow-400 fill-current"
                                      : "text-gray-600"
                                  }`}
                                />
                              ))}
                              <span className="text-xs text-gray-400 mr-1">{signal.confidence}%</span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3 space-x-reverse">
                            <div className={`flex items-center px-2 py-1 rounded-full ${statusInfo.bg}`}>
                              <StatusIcon className={`w-3 h-3 ml-1 ${statusInfo.color}`} />
                              <span className={`text-xs font-medium ${statusInfo.color}`}>{statusInfo.text}</span>
                            </div>
                            <div className="text-sm text-gray-400">{signal.time}</div>
                          </div>
                        </div>
                        <div className="mt-2">
                          <p className="text-sm text-gray-300">{signal.description}</p>
                          <div className="flex items-center mt-2 space-x-2 space-x-reverse">
                            <span className="text-xs text-gray-400">المحلل:</span>
                            <span className="text-xs font-medium text-blue-400">{signal.analyst}</span>
                            <span className="text-xs text-gray-400">•</span>
                            <span className="text-xs text-gray-400">المخاطرة/العائد:</span>
                            <span className="text-xs font-medium text-green-400">{signal.riskReward}</span>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                          <div className="text-center">
                            <div className="text-xs text-gray-400 mb-1">نقطة الدخول</div>
                            <div className="font-bold text-blue-400">{signal.entry}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-gray-400 mb-1">السعر الحالي</div>
                            <div className="font-bold text-white">{signal.currentPrice}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-gray-400 mb-1">جني الأرباح</div>
                            <div className="space-y-1">
                              {signal.tp.map((tp, index) => (
                                <div key={index} className="text-xs font-bold text-green-400">
                                  TP{index + 1}: {tp}
                                </div>
                              ))}
                            </div>
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-gray-400 mb-1">وقف الخسارة</div>
                            <div className="font-bold text-red-400">{signal.sl}</div>
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-gray-400 mb-1">النتيجة</div>
                            <div
                              className={`font-bold ${signal.profit.includes("+") ? "text-green-400" : signal.profit.includes("-") ? "text-red-400" : "text-gray-400"}`}
                            >
                              {signal.profit}
                            </div>
                            <div
                              className={`text-xs ${signal.pips.includes("+") ? "text-green-400" : signal.pips.includes("-") ? "text-red-400" : "text-gray-400"}`}
                            >
                              {signal.pips} نقطة
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <span className="text-sm text-gray-400">{signal.strategy}</span>
                            <div className="flex flex-wrap gap-1">
                              {signal.tags.map((tag, index) => (
                                <Badge key={index} variant="secondary" className="text-xs bg-gray-700 text-gray-300">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <Button variant="outline" size="sm">
                              <Share2 className="w-3 h-3 ml-1" />
                              مشاركة
                            </Button>
                            <Button variant="outline" size="sm">
                              <Bell className="w-3 h-3 ml-1" />
                              تنبيه
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <h3 className="text-lg font-semibold">ملخص الأداء اليومي</h3>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">12</div>
                      <div className="text-sm text-gray-400">توصيات نشطة</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">8</div>
                      <div className="text-sm text-gray-400">توصيات مغلقة</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">87%</div>
                      <div className="text-sm text-gray-400">نسبة النجاح</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">+$1,247</div>
                      <div className="text-sm text-gray-400">إجمالي الربح</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="charts" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">الرسوم البيانية التفاعلية</h2>
                <div className="flex items-center space-x-4 space-x-reverse">
                  <div className="flex space-x-2 space-x-reverse">
                    <Button
                      variant={chartType === "forex" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setChartType("forex")}
                    >
                      فوركس
                    </Button>
                    <Button
                      variant={chartType === "crypto" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setChartType("crypto")}
                    >
                      كريبتو
                    </Button>
                    <Button
                      variant={chartType === "commodities" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setChartType("commodities")}
                    >
                      السلع
                    </Button>
                  </div>
                  <div className="flex space-x-2 space-x-reverse">
                    <Button
                      variant={selectedTimeframe === "1m" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedTimeframe("1m")}
                    >
                      1د
                    </Button>
                    <Button
                      variant={selectedTimeframe === "5m" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedTimeframe("5m")}
                    >
                      5د
                    </Button>
                    <Button
                      variant={selectedTimeframe === "1h" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedTimeframe("1h")}
                    >
                      1س
                    </Button>
                    <Button
                      variant={selectedTimeframe === "4h" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedTimeframe("4h")}
                    >
                      4س
                    </Button>
                    <Button
                      variant={selectedTimeframe === "1D" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedTimeframe("1D")}
                    >
                      1ي
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between bg-gray-800 p-4 rounded-lg">
                <div className="flex items-center space-x-4 space-x-reverse">
                  <h3 className="font-semibold">الرمز المحدد:</h3>
                  <select
                    value={selectedSymbol}
                    onChange={(e) => setSelectedSymbol(e.target.value)}
                    className="bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                  >
                    {chartType === "forex" && (
                      <>
                        <option value="EURUSD">EUR/USD</option>
                        <option value="GBPUSD">GBP/USD</option>
                        <option value="USDJPY">USD/JPY</option>
                        <option value="USDCHF">USD/CHF</option>
                        <option value="AUDUSD">AUD/USD</option>
                        <option value="USDCAD">USD/CAD</option>
                      </>
                    )}
                    {chartType === "crypto" && (
                      <>
                        <option value="BTCUSDT">BTC/USDT</option>
                        <option value="ETHUSDT">ETH/USDT</option>
                        <option value="ADAUSDT">ADA/USDT</option>
                        <option value="XRPUSDT">XRP/USDT</option>
                        <option value="DOTUSDT">DOT/USDT</option>
                        <option value="LINKUSDT">LINK/USDT</option>
                      </>
                    )}
                    {chartType === "commodities" && (
                      <>
                        <option value="XAUUSD">الذهب/USD</option>
                        <option value="XAGUSD">الفضة/USD</option>
                        <option value="USOIL">النفط الخام</option>
                        <option value="UKOIL">برنت</option>
                      </>
                    )}
                  </select>
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Button variant="outline" size="sm">
                    <RefreshCw className="w-4 h-4 ml-2" />
                    تحديث
                  </Button>
                  <Button variant="outline" size="sm">
                    <Maximize2 className="w-4 h-4 ml-2" />
                    ملء الشاشة
                  </Button>
                  <Button variant="outline" size="sm">
                    <Settings className="w-4 h-4 ml-2" />
                    الإعدادات
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Main Chart */}
                <div className="lg:col-span-3">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="p-2">
                      <div className="relative">
                        <iframe
                          src={`https://www.tradingview.com/widgetembed/?frameElementId=tradingview_chart&symbol=${
                            chartType === "forex"
                              ? `FX_IDC:${selectedSymbol}`
                              : chartType === "crypto"
                                ? `BINANCE:${selectedSymbol}`
                                : `OANDA:${selectedSymbol}`
                          }&interval=${selectedTimeframe}&hidesidetoolbar=1&hidetoptoolbar=0&symboledit=1&saveimage=1&toolbarbg=1e1e1e&studies=RSI%7CMACD%7CMovingAverage&theme=dark&style=1&timezone=Asia%2FRiyadh&withdateranges=1&hideideas=1&hidevolume=0&locale=ar`}
                          width="100%"
                          height="500"
                          frameBorder="0"
                          allowTransparency={true}
                          scrolling="no"
                          className="rounded-lg"
                        />
                        <div className="absolute top-4 right-4 bg-black bg-opacity-50 px-3 py-1 rounded text-sm font-medium">
                          منصة خطاب للتداول
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Chart Tools Sidebar */}
                <div className="space-y-4">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">المؤشرات الفنية</h3>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        RSI
                      </Button>
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        MACD
                      </Button>
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        المتوسط المتحرك
                      </Button>
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        بولينجر باند
                      </Button>
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        ستوكاستيك
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">أدوات الرسم</h3>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        خط الاتجاه
                      </Button>
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        مستويات فيبوناتشي
                      </Button>
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        الدعم والمقاومة
                      </Button>
                      <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                        القنوات السعرية
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">معلومات الرمز</h3>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">السعر الحالي:</span>
                        <span className="font-bold text-green-400">1.0852</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">التغيير:</span>
                        <span className="font-bold text-green-400">+0.0012</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">أعلى سعر:</span>
                        <span className="font-bold">1.0865</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">أقل سعر:</span>
                        <span className="font-bold">1.0840</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">الحجم:</span>
                        <span className="font-bold">2.5M</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Multiple Chart View */}
              <div className="mt-8">
                <h3 className="text-lg font-semibold mb-4">مقارنة الأدوات</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader className="pb-2">
                      <h4 className="font-medium">EUR/USD</h4>
                    </CardHeader>
                    <CardContent className="p-2">
                      <iframe
                        src="https://www.tradingview.com/widgetembed/?frameElementId=tradingview_mini1&symbol=FX_IDC:EURUSD&interval=1h&hidesidetoolbar=1&hidetoptoolbar=1&symboledit=0&saveimage=0&toolbarbg=1e1e1e&theme=dark&style=1&timezone=Asia%2FRiyadh&locale=ar"
                        width="100%"
                        height="200"
                        frameBorder="0"
                        allowTransparency={true}
                        scrolling="no"
                        className="rounded"
                      />
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader className="pb-2">
                      <h4 className="font-medium">BTC/USDT</h4>
                    </CardHeader>
                    <CardContent className="p-2">
                      <iframe
                        src="https://www.tradingview.com/widgetembed/?frameElementId=tradingview_mini2&symbol=BINANCE:BTCUSDT&interval=1h&hidesidetoolbar=1&hidetoptoolbar=1&symboledit=0&saveimage=0&toolbarbg=1e1e1e&theme=dark&style=1&timezone=Asia%2FRiyadh&locale=ar"
                        width="100%"
                        height="200"
                        frameBorder="0"
                        allowTransparency={true}
                        scrolling="no"
                        className="rounded"
                      />
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="education" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">المكتبة التعليمية</h2>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <input
                      type="text"
                      placeholder="البحث في المحتوى التعليمي..."
                      className="bg-gray-700 text-white pl-4 pr-10 py-2 rounded-lg border border-gray-600 focus:border-blue-500 w-64"
                    />
                  </div>
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 ml-2" />
                    فلترة
                  </Button>
                </div>
              </div>

              {/* Learning Path Overview */}
              <Card className="bg-gradient-to-r from-blue-600 to-purple-600 border-blue-500">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between text-white">
                    <div>
                      <h3 className="text-xl font-bold mb-2">مسار التعلم الشخصي</h3>
                      <p className="text-blue-100 mb-4">تقدمك في رحلة تعلم التداول</p>
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <div className="text-center">
                          <div className="text-2xl font-bold">12</div>
                          <div className="text-sm text-blue-100">دروس مكتملة</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold">3</div>
                          <div className="text-sm text-blue-100">دورات نشطة</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold">45</div>
                          <div className="text-sm text-blue-100">ساعات تعلم</div>
                        </div>
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="w-24 h-24 rounded-full border-4 border-white border-opacity-30 flex items-center justify-center mb-2">
                        <span className="text-2xl font-bold">68%</span>
                      </div>
                      <div className="text-sm text-blue-100">التقدم الإجمالي</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Access Tabs */}
              <div className="flex flex-wrap gap-2">
                <Button variant="default" size="sm">
                  <BookOpen className="w-4 h-4 ml-2" />
                  جميع المحتويات
                </Button>
                <Button variant="outline" size="sm">
                  <Video className="w-4 h-4 ml-2" />
                  الفيديوهات
                </Button>
                <Button variant="outline" size="sm">
                  <FileText className="w-4 h-4 ml-2" />
                  المقالات
                </Button>
                <Button variant="outline" size="sm">
                  <Award className="w-4 h-4 ml-2" />
                  الدورات
                </Button>
                <Button variant="outline" size="sm">
                  <Globe className="w-4 h-4 ml-2" />
                  الندوات
                </Button>
              </div>

              {/* Featured Strategies */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold">استراتيجيات التداول المميزة</h3>
                  <Button variant="ghost" size="sm">
                    عرض الكل
                    <ChevronRight className="w-4 h-4 mr-2" />
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {educationalContent.strategies.map((strategy) => (
                    <Card
                      key={strategy.id}
                      className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer"
                    >
                      <div className="relative">
                        <img
                          src={strategy.thumbnail || "/placeholder.svg"}
                          alt={strategy.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <div className="absolute top-2 right-2">
                          <Badge variant={strategy.type === "video" ? "default" : "secondary"} className="text-xs">
                            {strategy.type === "video" ? (
                              <>
                                <Play className="w-3 h-3 ml-1" />
                                فيديو
                              </>
                            ) : (
                              <>
                                <FileText className="w-3 h-3 ml-1" />
                                مقال
                              </>
                            )}
                          </Badge>
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 px-2 py-1 rounded text-xs text-white">
                          {strategy.duration}
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="outline" className="text-xs">
                            {strategy.level}
                          </Badge>
                          <div className="flex items-center space-x-1 space-x-reverse">
                            <Star className="w-3 h-3 text-yellow-400 fill-current" />
                            <span className="text-xs text-gray-400">{strategy.rating}</span>
                          </div>
                        </div>
                        <h4 className="font-semibold mb-2 line-clamp-2">{strategy.title}</h4>
                        <p className="text-sm text-gray-400 mb-3 line-clamp-2">{strategy.description}</p>
                        <div className="flex items-center justify-between text-xs text-gray-400">
                          <div className="flex items-center">
                            <User className="w-3 h-3 ml-1" />
                            {strategy.instructor}
                          </div>
                          <div className="flex items-center">
                            <Eye className="w-3 h-3 ml-1" />
                            {strategy.views.toLocaleString()}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Courses Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold">الدورات التدريبية</h3>
                  <Button variant="ghost" size="sm">
                    عرض الكل
                    <ChevronRight className="w-4 h-4 mr-2" />
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {educationalContent.courses.map((course) => (
                    <Card
                      key={course.id}
                      className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer"
                    >
                      <div className="relative">
                        <img
                          src={course.thumbnail || "/placeholder.svg"}
                          alt={course.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <div className="absolute top-2 right-2">
                          <Badge variant={course.price === "مجاني" ? "default" : "secondary"} className="text-xs">
                            {course.price}
                          </Badge>
                        </div>
                        {course.progress > 0 && (
                          <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-70 p-2">
                            <div className="flex items-center justify-between text-xs text-white mb-1">
                              <span>التقدم</span>
                              <span>{course.progress}%</span>
                            </div>
                            <div className="w-full bg-gray-600 rounded-full h-1">
                              <div className="bg-blue-500 h-1 rounded-full" style={{ width: `${course.progress}%` }} />
                            </div>
                          </div>
                        )}
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="outline" className="text-xs">
                            {course.level}
                          </Badge>
                          <div className="flex items-center space-x-1 space-x-reverse">
                            <Star className="w-3 h-3 text-yellow-400 fill-current" />
                            <span className="text-xs text-gray-400">{course.rating}</span>
                          </div>
                        </div>
                        <h4 className="font-semibold mb-2 line-clamp-2">{course.title}</h4>
                        <p className="text-sm text-gray-400 mb-3 line-clamp-2">{course.description}</p>
                        <div className="space-y-2 text-xs text-gray-400">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Clock3 className="w-3 h-3 ml-1" />
                              {course.duration}
                            </div>
                            <div className="flex items-center">
                              <BookOpen className="w-3 h-3 ml-1" />
                              {course.lessons} درس
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <User className="w-3 h-3 ml-1" />
                              {course.instructor}
                            </div>
                            <div className="flex items-center">
                              <Users className="w-3 h-3 ml-1" />
                              {course.students.toLocaleString()}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Webinars Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold">الندوات المباشرة</h3>
                  <Button variant="ghost" size="sm">
                    عرض الكل
                    <ChevronRight className="w-4 h-4 mr-2" />
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {educationalContent.webinars.map((webinar) => (
                    <Card
                      key={webinar.id}
                      className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer"
                    >
                      <div className="flex">
                        <div className="relative flex-shrink-0">
                          <img
                            src={webinar.thumbnail || "/placeholder.svg"}
                            alt={webinar.title}
                            className="w-32 h-32 object-cover rounded-r-lg"
                          />
                          <div className="absolute top-2 right-2">
                            <Badge
                              variant={webinar.status === "upcoming" ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {webinar.status === "upcoming" ? "قادم" : "مكتمل"}
                            </Badge>
                          </div>
                        </div>
                        <CardContent className="p-4 flex-1">
                          <h4 className="font-semibold mb-2 line-clamp-2">{webinar.title}</h4>
                          <p className="text-sm text-gray-400 mb-3 line-clamp-2">{webinar.description}</p>
                          <div className="space-y-2 text-xs text-gray-400">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Calendar className="w-3 h-3 ml-1" />
                                {new Date(webinar.date).toLocaleDateString("ar-SA")}
                              </div>
                              <div className="flex items-center">
                                <Clock3 className="w-3 h-3 ml-1" />
                                {webinar.time}
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <User className="w-3 h-3 ml-1" />
                                {webinar.instructor}
                              </div>
                              <div className="flex items-center">
                                <Users className="w-3 h-3 ml-1" />
                                {webinar.attendees} مشارك
                              </div>
                            </div>
                          </div>
                          <Button size="sm" className="w-full mt-3">
                            {webinar.status === "upcoming" ? "سجل الآن" : "شاهد التسجيل"}
                          </Button>
                        </CardContent>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Articles Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold">المقالات التعليمية</h3>
                  <Button variant="ghost" size="sm">
                    عرض الكل
                    <ChevronRight className="w-4 h-4 mr-2" />
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {educationalContent.articles.map((article) => (
                    <Card
                      key={article.id}
                      className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer"
                    >
                      <div className="relative">
                        <img
                          src={article.thumbnail || "/placeholder.svg"}
                          alt={article.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <div className="absolute top-2 right-2">
                          <Badge variant="outline" className="text-xs bg-black bg-opacity-70">
                            {article.category}
                          </Badge>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h4 className="font-semibold mb-2 line-clamp-2">{article.title}</h4>
                        <p className="text-sm text-gray-400 mb-3 line-clamp-2">{article.description}</p>
                        <div className="flex items-center justify-between text-xs text-gray-400">
                          <div className="flex items-center">
                            <User className="w-3 h-3 ml-1" />
                            {article.author}
                          </div>
                          <div className="flex items-center">
                            <Clock3 className="w-3 h-3 ml-1" />
                            {article.readTime}
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
                          <div className="flex items-center">
                            <Calendar className="w-3 h-3 ml-1" />
                            {new Date(article.date).toLocaleDateString("ar-SA")}
                          </div>
                          <div className="flex items-center">
                            <Eye className="w-3 h-3 ml-1" />
                            {article.views.toLocaleString()}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Learning Statistics */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <h3 className="text-lg font-semibold">إحصائيات التعلم</h3>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">156</div>
                      <div className="text-sm text-gray-400">فيديو تعليمي</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">89</div>
                      <div className="text-sm text-gray-400">مقال متخصص</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-400">24</div>
                      <div className="text-sm text-gray-400">دورة تدريبية</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-400">12</div>
                      <div className="text-sm text-gray-400">ندوة شهرية</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tools" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">أدوات التداول المتقدمة</h2>
                <div className="text-sm text-gray-400">جميع الأدوات التي تحتاجها للتداول الناجح</div>
              </div>

              {/* Trading Calculators */}
              <div>
                <h3 className="text-xl font-semibold mb-4">حاسبات التداول</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <Calculator className="w-8 h-8 text-blue-400" />
                        <Badge variant="outline" className="text-xs">
                          مجاني
                        </Badge>
                      </div>
                      <h3 className="font-semibold mb-2">حاسبة الربح والخسارة</h3>
                      <p className="text-sm text-gray-400 mb-4">احسب الربح والخسارة المحتملة قبل فتح الصفقة</p>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-xs text-gray-400">حجم المركز</label>
                            <input
                              type="number"
                              placeholder="1.0"
                              className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-gray-400">سعر الدخول</label>
                            <input
                              type="number"
                              placeholder="1.0850"
                              className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-xs text-gray-400">سعر الخروج</label>
                            <input
                              type="number"
                              placeholder="1.0900"
                              className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-gray-400">العملة</label>
                            <select className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500">
                              <option>USD</option>
                              <option>EUR</option>
                              <option>GBP</option>
                            </select>
                          </div>
                        </div>
                        <Button size="sm" className="w-full">
                          احسب
                        </Button>
                        <div className="bg-gray-700 p-2 rounded text-center">
                          <div className="text-xs text-gray-400">الربح المتوقع</div>
                          <div className="text-lg font-bold text-green-400">+$500</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <Target className="w-8 h-8 text-green-400" />
                        <Badge variant="outline" className="text-xs">
                          مجاني
                        </Badge>
                      </div>
                      <h3 className="font-semibold mb-2">حاسبة حجم المركز</h3>
                      <p className="text-sm text-gray-400 mb-4">احسب الحجم المناسب للمركز حسب المخاطرة</p>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-xs text-gray-400">رأس المال</label>
                            <input
                              type="number"
                              placeholder="10000"
                              className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-gray-400">نسبة المخاطرة %</label>
                            <input
                              type="number"
                              placeholder="2"
                              className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-xs text-gray-400">سعر الدخول</label>
                            <input
                              type="number"
                              placeholder="1.0850"
                              className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-gray-400">وقف الخسارة</label>
                            <input
                              type="number"
                              placeholder="1.0800"
                              className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                            />
                          </div>
                        </div>
                        <Button size="sm" className="w-full">
                          احسب
                        </Button>
                        <div className="bg-gray-700 p-2 rounded text-center">
                          <div className="text-xs text-gray-400">حجم المركز المناسب</div>
                          <div className="text-lg font-bold text-blue-400">4.0 لوت</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <PieChart className="w-8 h-8 text-purple-400" />
                        <Badge variant="outline" className="text-xs">
                          مجاني
                        </Badge>
                      </div>
                      <h3 className="font-semibold mb-2">حاسبة النقطة</h3>
                      <p className="text-sm text-gray-400 mb-4">احسب قيمة النقطة لأي زوج عملات</p>
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs text-gray-400">زوج العملات</label>
                          <select className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500">
                            <option>EUR/USD</option>
                            <option>GBP/USD</option>
                            <option>USD/JPY</option>
                            <option>USD/CHF</option>
                          </select>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-xs text-gray-400">حجم المركز</label>
                            <input
                              type="number"
                              placeholder="1.0"
                              className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-gray-400">عملة الحساب</label>
                            <select className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500">
                              <option>USD</option>
                              <option>EUR</option>
                            </select>
                          </div>
                        </div>
                        <Button size="sm" className="w-full">
                          احسب
                        </Button>
                        <div className="bg-gray-700 p-2 rounded text-center">
                          <div className="text-xs text-gray-400">قيمة النقطة</div>
                          <div className="text-lg font-bold text-purple-400">$10</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Market Analysis Tools */}
              <div>
                <h3 className="text-xl font-semibold mb-4">أدوات تحليل السوق</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <Calendar className="w-8 h-8 text-green-400" />
                        <Badge variant="default" className="text-xs">
                          مباشر
                        </Badge>
                      </div>
                      <h3 className="font-semibold mb-2">التقويم الاقتصادي</h3>
                      <p className="text-sm text-gray-400 mb-4">تابع الأحداث الاقتصادية المهمة وتأثيرها على الأسواق</p>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between p-2 bg-gray-700 rounded">
                          <div>
                            <div className="text-sm font-medium">بيانات التضخم الأمريكي</div>
                            <div className="text-xs text-gray-400">15:30 GMT</div>
                          </div>
                          <Badge variant="destructive" className="text-xs">
                            تأثير عالي
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between p-2 bg-gray-700 rounded">
                          <div>
                            <div className="text-sm font-medium">قرار البنك المركزي الأوروبي</div>
                            <div className="text-xs text-gray-400">غداً 14:00</div>
                          </div>
                          <Badge variant="default" className="text-xs">
                            تأثير متوسط
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between p-2 bg-gray-700 rounded">
                          <div>
                            <div className="text-sm font-medium">بيانات الوظائف البريطانية</div>
                            <div className="text-xs text-gray-400">الجمعة 10:30</div>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            تأثير منخفض
                          </Badge>
                        </div>
                      </div>
                      <Button size="sm" className="w-full mt-3">
                        عرض التقويم الكامل
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <DollarSign className="w-8 h-8 text-blue-400" />
                        <Badge variant="outline" className="text-xs">
                          مجاني
                        </Badge>
                      </div>
                      <h3 className="font-semibold mb-2">محول العملات</h3>
                      <p className="text-sm text-gray-400 mb-4">تحويل بين جميع العملات العالمية بأسعار حية</p>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-xs text-gray-400">من</label>
                            <select className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500">
                              <option>USD</option>
                              <option>EUR</option>
                              <option>GBP</option>
                              <option>JPY</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-xs text-gray-400">إلى</label>
                            <select className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500">
                              <option>EUR</option>
                              <option>USD</option>
                              <option>GBP</option>
                              <option>JPY</option>
                            </select>
                          </div>
                        </div>
                        <div>
                          <label className="text-xs text-gray-400">المبلغ</label>
                          <input
                            type="number"
                            placeholder="1000"
                            className="w-full bg-gray-700 text-white px-2 py-1 rounded text-sm border border-gray-600 focus:border-blue-500"
                          />
                        </div>
                        <div className="bg-gray-700 p-3 rounded">
                          <div className="flex items-center justify-between">
                            <span className="text-sm">1 USD =</span>
                            <span className="font-bold text-blue-400">0.9234 EUR</span>
                          </div>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-sm">1000 USD =</span>
                            <span className="font-bold text-green-400">923.40 EUR</span>
                          </div>
                        </div>
                        <Button size="sm" className="w-full">
                          تحويل
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <BarChart3 className="w-8 h-8 text-orange-400" />
                        <Badge variant="outline" className="text-xs">
                          تحليل
                        </Badge>
                      </div>
                      <h3 className="font-semibold mb-2">مؤشر الخوف والطمع</h3>
                      <p className="text-sm text-gray-400 mb-4">قياس مشاعر السوق والاتجاه العام للمستثمرين</p>
                      <div className="space-y-3">
                        <div className="text-center">
                          <div className="w-24 h-24 mx-auto rounded-full border-4 border-orange-400 flex items-center justify-center mb-2">
                            <span className="text-2xl font-bold text-orange-400">67</span>
                          </div>
                          <div className="text-sm font-medium text-orange-400">طمع</div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span className="text-red-400">خوف شديد</span>
                            <span className="text-green-400">طمع شديد</span>
                          </div>
                          <div className="w-full bg-gray-700 rounded-full h-2">
                            <div className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 h-2 rounded-full relative">
                              <div
                                className="absolute top-0 w-1 h-2 bg-white rounded-full"
                                style={{ left: "67%" }}
                              ></div>
                            </div>
                          </div>
                        </div>
                        <div className="text-xs text-gray-400 text-center">آخر تحديث: منذ ساعة واحدة</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Risk Management Tools */}
              <div>
                <h3 className="text-xl font-semibold mb-4">أدوات إدارة المخاطر</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold">حاسبة المخاطرة المتقدمة</h3>
                        <AlertTriangle className="w-5 h-5 text-yellow-400" />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-sm text-gray-400">رأس المال الإجمالي</label>
                          <input
                            type="number"
                            placeholder="50000"
                            className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-gray-400">نسبة المخاطرة لكل صفقة %</label>
                          <input
                            type="number"
                            placeholder="2"
                            className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-sm text-gray-400">عدد الصفقات المتزامنة</label>
                          <input
                            type="number"
                            placeholder="3"
                            className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-gray-400">نسبة الربح المستهدفة %</label>
                          <input
                            type="number"
                            placeholder="6"
                            className="w-full bg-gray-700 text-white px-3 py-2 rounded border border-gray-600 focus:border-blue-500"
                          />
                        </div>
                      </div>
                      <Button className="w-full">حساب المخاطرة</Button>
                      <div className="bg-gray-700 p-4 rounded space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-400">المخاطرة لكل صفقة:</span>
                          <span className="font-bold text-red-400">$1,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">إجمالي المخاطرة:</span>
                          <span className="font-bold text-red-400">$3,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">الربح المستهدف:</span>
                          <span className="font-bold text-green-400">$3,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">نسبة المخاطرة/العائد:</span>
                          <span className="font-bold text-blue-400">1:1</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold">متتبع الأداء</h3>
                        <TrendingUp className="w-5 h-5 text-green-400" />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 bg-gray-700 rounded">
                          <div className="text-2xl font-bold text-green-400">+15.3%</div>
                          <div className="text-xs text-gray-400">العائد الشهري</div>
                        </div>
                        <div className="text-center p-3 bg-gray-700 rounded">
                          <div className="text-2xl font-bold text-blue-400">87%</div>
                          <div className="text-xs text-gray-400">نسبة النجاح</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 bg-gray-700 rounded">
                          <div className="text-2xl font-bold text-purple-400">1:2.8</div>
                          <div className="text-xs text-gray-400">متوسط المخاطرة/العائد</div>
                        </div>
                        <div className="text-center p-3 bg-gray-700 rounded">
                          <div className="text-2xl font-bold text-orange-400">45</div>
                          <div className="text-xs text-gray-400">إجمالي الصفقات</div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">أفضل صفقة:</span>
                          <span className="font-bold text-green-400">+$1,250</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">أسوأ صفقة:</span>
                          <span className="font-bold text-red-400">-$450</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">متوسط الربح:</span>
                          <span className="font-bold text-blue-400">+$320</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">أقصى انخفاض:</span>
                          <span className="font-bold text-yellow-400">-8.2%</span>
                        </div>
                      </div>
                      <Button variant="outline" className="w-full bg-transparent">
                        عرض التقرير المفصل
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Advanced Tools */}
              <div>
                <h3 className="text-xl font-semibold mb-4">أدوات متقدمة</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-colors cursor-pointer">
                    <CardContent className="p-6 text-center">
                      <Globe className="w-8 h-8 text-blue-400 mx-auto mb-3" />
                      <h4 className="font-semibold mb-2">مراقب الارتباط</h4>
                      <p className="text-xs text-gray-400">تتبع الارتباط بين أزواج العملات</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-colors cursor-pointer">
                    <CardContent className="p-6 text-center">
                      <Activity className="w-8 h-8 text-green-400 mx-auto mb-3" />
                      <h4 className="font-semibold mb-2">مؤشر التقلبات</h4>
                      <p className="text-xs text-gray-400">قياس مستوى التقلبات في السوق</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-colors cursor-pointer">
                    <CardContent className="p-6 text-center">
                      <Clock className="w-8 h-8 text-purple-400 mx-auto mb-3" />
                      <h4 className="font-semibold mb-2">مؤقت الجلسات</h4>
                      <p className="text-xs text-gray-400">تتبع أوقات جلسات التداول العالمية</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-colors cursor-pointer">
                    <CardContent className="p-6 text-center">
                      <Star className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
                      <h4 className="font-semibold mb-2">مقيم الإشارات</h4>
                      <p className="text-xs text-gray-400">تقييم جودة الإشارات والتوصيات</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Tools Usage Statistics */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <h3 className="text-lg font-semibold">إحصائيات استخدام الأدوات</h3>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">1,247</div>
                      <div className="text-sm text-gray-400">حسابات اليوم</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">89%</div>
                      <div className="text-sm text-gray-400">دقة الحسابات</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-400">24/7</div>
                      <div className="text-sm text-gray-400">متاح دائماً</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-400">15</div>
                      <div className="text-sm text-gray-400">أداة متخصصة</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="community" className="space-y-6">
              <h2 className="text-xl font-semibold">مجتمع المتداولين</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-6">
                    <MessageSquare className="w-8 h-8 text-blue-400 mb-4" />
                    <h3 className="font-semibold mb-2">منتدى النقاش</h3>
                    <p className="text-sm text-gray-400 mb-4">شارك في النقاشات مع المتداولين الآخرين</p>
                    <Button className="w-full">انضم للمنتدى</Button>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700">
                  <CardContent className="p-6">
                    <Users className="w-8 h-8 text-green-400 mb-4" />
                    <h3 className="font-semibold mb-2">غرف التداول المباشرة</h3>
                    <p className="text-sm text-gray-400 mb-4">تداول مع المحترفين في الوقت الفعلي</p>
                    <Button className="w-full">دخول الغرفة</Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Enhanced news tab */}
            <TabsContent value="news" className="space-y-6">
              <h2 className="text-xl font-semibold">الأخبار الاقتصادية</h2>

              <div className="grid gap-4">
                {mockNews.map((news, index) => (
                  <Card key={index} className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3 space-x-reverse">
                        <Globe className="w-5 h-5 text-blue-400 mt-1 flex-shrink-0" />
                        <div className="flex-1">
                          <p className="text-gray-200">{news}</p>
                          <div className="flex items-center mt-2 text-sm text-gray-400">
                            <span>منذ {Math.floor(Math.random() * 60) + 1} دقيقة</span>
                            <Badge variant="outline" className="mr-2 text-xs">
                              تأثير عالي
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
