"use client"

import { useState } from "react"
import { useAuth } from "../contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function AdminDashboard() {
  const { user, logout, getAllUsers, approveUser, rejectUser, deleteUser } = useAuth()
  const [users, setUsers] = useState(getAllUsers())
  const [activeTab, setActiveTab] = useState<"pending" | "approved" | "rejected" | "all">("pending")

  const refreshUsers = () => {
    setUsers(getAllUsers())
  }

  const handleApprove = (userId: string) => {
    approveUser(userId)
    refreshUsers()
  }

  const handleReject = (userId: string) => {
    rejectUser(userId)
    refreshUsers()
  }

  const handleDelete = (userId: string) => {
    if (confirm("هل أنت متأكد من حذف هذا المستخدم؟")) {
      deleteUser(userId)
      refreshUsers()
    }
  }

  const filteredUsers = users.filter((u) => {
    if (activeTab === "all") return u.role !== "admin"
    return u.status === activeTab && u.role !== "admin"
  })

  const pendingCount = users.filter((u) => u.status === "pending").length
  const approvedCount = users.filter((u) => u.status === "approved" && u.role !== "admin").length
  const rejectedCount = users.filter((u) => u.status === "rejected").length

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
            في الانتظار
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            مُوافق عليه
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800">
            مرفوض
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">لوحة تحكم المدير</h1>
              <p className="text-gray-600">مرحباً {user?.name}</p>
            </div>
            <Button onClick={logout} variant="outline">
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center ml-4">
                  <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{pendingCount}</p>
                  <p className="text-gray-600">في الانتظار</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center ml-4">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{approvedCount}</p>
                  <p className="text-gray-600">مُوافق عليه</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center ml-4">
                  <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{rejectedCount}</p>
                  <p className="text-gray-600">مرفوض</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center ml-4">
                  <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{users.filter((u) => u.role !== "admin").length}</p>
                  <p className="text-gray-600">إجمالي المستخدمين</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Users Management */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-bold">إدارة المستخدمين</CardTitle>

            {/* Tabs */}
            <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
              <button
                onClick={() => setActiveTab("pending")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === "pending" ? "bg-white text-blue-600 shadow-sm" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                في الانتظار ({pendingCount})
              </button>
              <button
                onClick={() => setActiveTab("approved")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === "approved" ? "bg-white text-blue-600 shadow-sm" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                مُوافق عليه ({approvedCount})
              </button>
              <button
                onClick={() => setActiveTab("rejected")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === "rejected" ? "bg-white text-blue-600 shadow-sm" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                مرفوض ({rejectedCount})
              </button>
              <button
                onClick={() => setActiveTab("all")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === "all" ? "bg-white text-blue-600 shadow-sm" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                الكل
              </button>
            </div>
          </CardHeader>
          <CardContent>
            {filteredUsers.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">لا توجد مستخدمين في هذه الفئة</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredUsers.map((u) => (
                  <div key={u.id} className="flex items-center justify-between p-4 border rounded-lg bg-white">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-medium text-gray-900">{u.name}</h3>
                        {getStatusBadge(u.status)}
                      </div>
                      <p className="text-sm text-gray-600">{u.email}</p>
                      <p className="text-xs text-gray-500">
                        تاريخ التسجيل: {new Date(u.createdAt).toLocaleDateString("ar-SA")}
                      </p>
                    </div>

                    <div className="flex gap-2">
                      {u.status === "pending" && (
                        <>
                          <Button
                            onClick={() => handleApprove(u.id)}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700"
                          >
                            موافقة
                          </Button>
                          <Button
                            onClick={() => handleReject(u.id)}
                            size="sm"
                            variant="outline"
                            className="border-red-300 text-red-600 hover:bg-red-50"
                          >
                            رفض
                          </Button>
                        </>
                      )}

                      {u.status === "rejected" && (
                        <Button
                          onClick={() => handleApprove(u.id)}
                          size="sm"
                          className="bg-green-600 hover:bg-green-700"
                        >
                          موافقة
                        </Button>
                      )}

                      {u.status === "approved" && (
                        <Button
                          onClick={() => handleReject(u.id)}
                          size="sm"
                          variant="outline"
                          className="border-red-300 text-red-600 hover:bg-red-50"
                        >
                          إلغاء الموافقة
                        </Button>
                      )}

                      <Button
                        onClick={() => handleDelete(u.id)}
                        size="sm"
                        variant="outline"
                        className="border-red-300 text-red-600 hover:bg-red-50"
                      >
                        حذف
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
